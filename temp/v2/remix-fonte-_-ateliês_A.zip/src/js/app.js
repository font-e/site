import { loadAtelies } from './atelies.js';

document.addEventListener('DOMContentLoaded', async () => {
  await loadAtelies();

  if (typeof ScrollTrigger !== 'undefined') {
    ScrollTrigger.refresh();
  }
});

