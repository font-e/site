/**
 * Módulo Ateliês - Residência Artística FONTE
 * Grid Suíço de 3 Colunas Independentes (4 + 4 + 4) com Gavetas Expansíveis
 */

export function updateHeaderHeight() {
  const header = document.getElementById('logo-controller');
  if (header) {
    const height = header.offsetHeight;
    document.documentElement.style.setProperty('--header-height', `${height}px`);
  }
}

export function loadAtelies() {
  updateHeaderHeight();
  window.addEventListener('resize', updateHeaderHeight);

  return fetch('./atelies.json')
    .then(response => {
      if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
      return response.json();
    })
    .then(data => {
      renderAtelies(data);
    })
    .catch(err => {
      console.warn('Erro ao carregar atelies.json:', err);
      renderEmptyState();
    });
}

function renderEmptyState() {
  const container = document.getElementById('atelies-grid-container');
  if (!container) return;
  container.innerHTML = `
    <div class="empty-state" style="padding: 48px 20px; font-size: var(--fs-meta); border-top: var(--border-width) solid var(--border-color); text-transform: uppercase; letter-spacing: 0.05em;">
      Nenhum ateliê cadastrado no momento.
    </div>
  `;
}

function renderAtelies(data) {
  const container = document.getElementById('atelies-grid-container');
  if (!container) return;
  container.innerHTML = '';

  const wrapper = document.createElement('div');
  wrapper.className = 'atelies-container';
  wrapper.id = 'atelies-wrapper';

  // Grid Mestre com 3 Colunas Independentes (4 + 4 + 4)
  const gridContainer = document.createElement('div');
  gridContainer.className = 'atelies-grid';
  gridContainer.id = 'atelies-columns-grid';

  // Criar as 3 colunas estruturais independentes
  const columns = [
    document.createElement('div'),
    document.createElement('div'),
    document.createElement('div')
  ];

  columns.forEach((col, idx) => {
    col.className = 'atelie-column';
    col.id = `atelie-column-${idx + 1}`;
    gridContainer.appendChild(col);
  });

  // Distribuir os 9 artistas nas 3 colunas independentes:
  // Coluna 1: 0 (Marcelo Amorim), 3 (Caio Borges), 6 (Nicole Kouts)
  // Coluna 2: 1 (Ósi), 4 (Gustavo Prata), 7 (Nina Lins)
  // Coluna 3: 2 (Luah Souza), 5 (Charlles Cunha), 8 (Pedro Gallego)
  data.forEach((artista, index) => {
    const colIndex = index % 3;
    const item = createAtelieCard(artista, index);
    columns[colIndex].appendChild(item);
  });

  wrapper.appendChild(gridContainer);
  container.appendChild(wrapper);

  attachAtelieInteractions(data);
}

function createAtelieCard(artista, index) {
  const card = document.createElement('article');
  card.className = 'atelie-item';
  card.id = `atelie-${artista.id}`;
  card.dataset.id = artista.id;
  card.dataset.state = 'closed';

  card.innerHTML = `
    <div class="atelie-header" id="header-${artista.id}" role="button" tabindex="0" aria-expanded="false">
      <div class="atelie-name-wrap">
        <h2 class="atelie-name">${artista.nome}</h2>
      </div>
      <p class="atelie-summary">${artista.sobre}</p>
    </div>

    <div class="atelie-drawer" id="drawer-${artista.id}" aria-hidden="true">
      <div class="atelie-drawer-inner">
        <div class="atelie-drawer-toolbar">
          <div class="atelie-drawer-tabs">
            <button type="button" class="atelie-tab-btn is-active" data-tab="sobre">Sobre</button>
            <button type="button" class="atelie-tab-btn" data-tab="pesquisa">Pesquisa</button>
            <button type="button" class="atelie-tab-btn" data-tab="obras">Projetos</button>
            <button type="button" class="atelie-tab-btn" data-tab="contato">Info</button>
          </div>
          <button type="button" class="atelie-close-btn" aria-label="Fechar gaveta">✕</button>
        </div>

        <div class="atelie-media-container">
          <img src="${artista.imagem}" alt="${artista.nome}" loading="lazy">
        </div>

        <div class="atelie-text-container">
          <p class="atelie-body-text" id="body-text-${artista.id}">${artista.sobre}</p>
          <div class="atelie-links-row" id="links-row-${artista.id}">
            ${artista.links && artista.links.instagram ? `<span class="atelie-link-item">${artista.links.instagram}</span>` : ''}
            ${artista.links && artista.links.portfolio ? `<span class="atelie-link-item">${artista.links.portfolio}</span>` : ''}
          </div>
        </div>
      </div>
    </div>
  `;

  return card;
}

function attachAtelieInteractions(data) {
  const dataMap = new Map(data.map(item => [item.id, item]));
  const items = document.querySelectorAll('.atelie-item');

  items.forEach(item => {
    const header = item.querySelector('.atelie-header');
    const closeBtn = item.querySelector('.atelie-close-btn');
    const tabBtns = item.querySelectorAll('.atelie-tab-btn');
    const artistId = item.dataset.id;
    const artistData = dataMap.get(artistId);

    // Clique no cabeçalho: toggle da gaveta
    header.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleDrawer(item);
    });

    // Acessibilidade via teclado
    header.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggleDrawer(item);
      }
    });

    // Botão de fechar interno da gaveta (✕)
    if (closeBtn) {
      closeBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        closeDrawer(item);
      });
    }

    // Abas de navegação interna no card expandido
    tabBtns.forEach(tab => {
      tab.addEventListener('click', (e) => {
        e.stopPropagation();
        const tabType = tab.dataset.tab;

        tabBtns.forEach(t => t.classList.remove('is-active'));
        tab.classList.add('is-active');

        updateDrawerTabContent(item, artistData, tabType);
      });
    });
  });
}

function updateDrawerTabContent(item, data, tabType) {
  if (!data) return;
  const textEl = item.querySelector('.atelie-body-text');
  const linksEl = item.querySelector('.atelie-links-row');
  const drawer = item.querySelector('.atelie-drawer');

  if (!textEl) return;

  if (tabType === 'sobre') {
    textEl.textContent = data.sobre || '';
    if (linksEl) linksEl.style.display = 'flex';
  } else if (tabType === 'pesquisa') {
    textEl.textContent = data.pesquisa || data.sobre || '';
    if (linksEl) linksEl.style.display = 'none';
  } else if (tabType === 'obras') {
    textEl.textContent = data.obras || 'Obras e projetos desenvolvidos na residência.';
    if (linksEl) linksEl.style.display = 'none';
  } else if (tabType === 'contato') {
    textEl.textContent = `Artista: ${data.nome}\nResidência Artística FONTE 2026.`;
    if (linksEl) linksEl.style.display = 'flex';
  }

  // Se a gaveta estiver aberta, ajusta suavemente o scrollHeight
  if (item.dataset.state === 'open' && drawer) {
    if (typeof gsap !== 'undefined') {
      gsap.to(drawer, {
        height: 'auto',
        duration: 0.3,
        ease: 'power2.out',
        onComplete: () => {
          if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.refresh();
        }
      });
    }
  }
}

function toggleDrawer(item) {
  if (item.dataset.state === 'closed') {
    openDrawer(item);
  } else {
    closeDrawer(item);
  }
}

function openDrawer(item, animate = true) {
  const drawer = item.querySelector('.atelie-drawer');
  const header = item.querySelector('.atelie-header');
  if (!drawer) return;

  item.dataset.state = 'open';
  item.classList.add('is-open');
  if (header) header.setAttribute('aria-expanded', 'true');
  drawer.setAttribute('aria-hidden', 'false');

  if (typeof gsap !== 'undefined' && animate) {
    gsap.killTweensOf(drawer);

    drawer.style.display = 'block';
    drawer.style.overflow = 'hidden';
    drawer.style.height = 'auto';
    const targetHeight = drawer.scrollHeight;
    drawer.style.height = '0px';
    drawer.style.opacity = '0';

    gsap.to(drawer, {
      height: targetHeight,
      opacity: 1,
      duration: 0.5,
      ease: 'power3.inOut',
      onComplete: () => {
        drawer.style.height = 'auto';
        drawer.style.overflow = 'visible';
        if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.refresh();
      }
    });
  } else {
    drawer.style.display = 'block';
    drawer.style.height = 'auto';
    drawer.style.overflow = 'visible';
    drawer.style.opacity = '1';
    if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.refresh();
  }
}

function closeDrawer(item, animate = true) {
  const drawer = item.querySelector('.atelie-drawer');
  const header = item.querySelector('.atelie-header');
  if (!drawer) return;

  item.dataset.state = 'closed';
  item.classList.remove('is-open');
  if (header) header.setAttribute('aria-expanded', 'false');
  drawer.setAttribute('aria-hidden', 'true');
  drawer.style.overflow = 'hidden';

  if (typeof gsap !== 'undefined' && animate) {
    gsap.killTweensOf(drawer);

    const currentHeight = drawer.scrollHeight;
    drawer.style.height = `${currentHeight}px`;

    gsap.to(drawer, {
      height: 0,
      opacity: 0,
      duration: 0.4,
      ease: 'power3.inOut',
      onComplete: () => {
        drawer.style.display = 'none';
        drawer.style.height = '0px';
        if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.refresh();
      }
    });
  } else {
    drawer.style.display = 'none';
    drawer.style.height = '0px';
    drawer.style.opacity = '0';
    if (typeof ScrollTrigger !== 'undefined') ScrollTrigger.refresh();
  }
}
